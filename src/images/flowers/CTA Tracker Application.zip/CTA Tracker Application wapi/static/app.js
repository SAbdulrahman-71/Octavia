// Wait for the DOM to be fully loaded before executing the script
document.addEventListener('DOMContentLoaded', function () {
    // Set the CSRF token for axios from the meta tag to handle secure POST requests
    axios.defaults.headers.common['X-CSRFToken'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Initialize a new Vue instance
    const app = new Vue({
      el: '#content', // Element to mount Vue application
      data: {
        searchVehicleId: '', // Stores the vehicle ID input by the user
        map: null, // Will hold the Leaflet map instance
        vehicleDetails: [], // Array to store vehicle details fetched from the API
        trackedVehicleIds: [], // Array to store IDs of tracked vehicles
      },
      methods: {
        searchVehicle() {
          // Function to fetch vehicle data from the server
          if (this.searchVehicleId.trim() !== '') {
            const vehicleUrl = `/api/get_vehicle/${this.searchVehicleId}`;
            axios.get(vehicleUrl)
              .then(response => {
                let vehicle = response.data['bustime-response']['vehicle'];
                if (!Array.isArray(vehicle)) {
                  vehicle = [vehicle]; // Ensure vehicle data is an array to handle multiple vehicles at a time
                }
                this.vehicleDetails = this.vehicleDetails.filter(veh => veh.vid !== this.searchVehicleId);
                this.vehicleDetails.push(...vehicle);
                this.updateMap(); // Update the map with new vehicle data
              })
              .catch(error => console.error('Error fetching vehicle information:', error));
          }
        },
        updateMap() {
          // Function to update the map with vehicle markers
          this.map.eachLayer(layer => {
            if (layer instanceof L.Marker) {
              this.map.removeLayer(layer); // Remove existing markers
            }
          });
          this.vehicleDetails.forEach(vehicle => {
            if (vehicle && vehicle.lat && vehicle.lon) {
              const coordinates = { lat: parseFloat(vehicle.lat), lon: parseFloat(vehicle.lon) };
              if (!isNaN(coordinates.lat) && !isNaN(coordinates.lon)) {
                const vehicleMarker = L.marker([coordinates.lat, coordinates.lon]).addTo(this.map);
                const popupContent = `
                  <b>Vehicle ID:</b> ${vehicle.vid}<br>
                  <b>Route:</b> ${vehicle.rt}<br>
                  <b>Trip ID:</b> ${vehicle.tatripid}<br>
                  <b>Heading:</b> ${vehicle.hdg}<br>
                  <b>Latitude:</b> ${vehicle.lat}<br>
                  <b>Longitude:</b> ${vehicle.lon}<br>
                  <b>Timestamp:</b> ${vehicle.tmstmp}<br>
                  <button class="delete-button" data-vid="${vehicle.vid}">Delete</button>
                `;
                vehicleMarker.bindPopup(popupContent).openPopup();
              } else {
                console.error('Invalid coordinates for vehicle:', vehicle.vid);
              }
            } else {
              console.error('Incomplete vehicle data for vehicle:', vehicle.vid);
            }
          });
        },
        deleteVehicle(vehicleId) {
          // Function to send a request to delete a vehicle from the tracking list
          axios.post(`/api/delete_vehicle/${vehicleId}`)
            .then(response => {
                console.log('Vehicle deleted successfully:', response.data.message);
                this.vehicleDetails = this.vehicleDetails.filter(vehicle => vehicle.vid !== vehicleId);
                this.updateMap(); // Refresh the map after deletion
            })
            .catch(error => {
                console.error('Error deleting vehicle:', error.response && error.response.data ? error.response.data.error : 'Unknown error');
            });
        },
        fetchTrackedVehicleDetails() {
          // Function to fetch all tracked vehicle details on initialization
          fetch('/api/get_tracked_vehicle_details')
            .then(response => response.json())
            .then(data => {
              const newVehicleDetails = data.vehicle_details;
              const existingVehicleIds = this.vehicleDetails.map(vehicle => vehicle.vid);
              const newVehicles = newVehicleDetails.filter(vehicle => !existingVehicleIds.includes(vehicle.vid));
              this.vehicleDetails = [...this.vehicleDetails, ...newVehicles];
              this.trackedVehicleIds = data.tracked_vehicle_ids;
              this.updateMap(); // Update map with all tracked vehicle details
            })
            .catch(error => console.error('Error fetching tracked vehicle details:', error));
        }
      },
      mounted() {
        // Setup the map when the Vue instance is mounted
        this.map = L.map('map').setView([41.8781, -87.6298], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data © OpenStreetMap contributors'
        }).addTo(this.map);
        this.fetchTrackedVehicleDetails(); // Initial fetch of vehicle details

        setTimeout(() => {
            this.trackedVehicleIds.forEach(vehicleId => {
                this.searchVehicleId = vehicleId;
                this.searchVehicle(); // Search each tracked vehicle and update map
            });
        }, 500);

        this.map.on('popupopen', (e) => {
            // Event listener for the delete button in popups
            const deleteButtons = document.querySelectorAll('.delete-button');
            deleteButtons.forEach(button => button.addEventListener('click', () => {
                const vehicleId = button.getAttribute('data-vid');
                this.deleteVehicle(vehicleId); // Call delete function on click
            }));
        });
      }
    });
});
