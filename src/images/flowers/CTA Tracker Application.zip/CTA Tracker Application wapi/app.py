from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import CSRFProtect, FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, Regexp
import requests
import xmltodict

# Initialize the Flask application
app = Flask(__name__)
CORS(app)
# Application configuration settings
app.config['SECRET_KEY'] = 'test'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
# Database setup with SQLAlchemy
db = SQLAlchemy(app)
# CSRF protection
csrf = CSRFProtect(app)
# Login management setup
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Database model for user
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

    def set_password(self, password):
        self.password = generate_password_hash(password, method='pbkdf2:sha256')

    def check_password(self, password):
        return check_password_hash(self.password, password)

# Database model for tracking vehicles
class TrackedVehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.String(20), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('tracked_vehicles', lazy='dynamic'))

# Form for user registration
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(4, 20)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=6)])
    submit = SubmitField('Register')

# Loads user from session
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Route for user signup
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = RegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose another username.', 'error')
            return redirect(url_for('signup'))
        new_user = User(username=form.username.data)
        new_user.set_password(form.password.data)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html', form=form)

# Route for user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('index'))
    return render_template('login.html')

# Route for user logout
@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Route for the index page
@app.route('/')
@login_required
def index():
    user = current_user
    tracked_vehicle_ids = [vehicle.vehicle_id for vehicle in user.tracked_vehicles.all()]
    return render_template('index.html', tracked_vehicle_ids=tracked_vehicle_ids)

# Route to get vehicle details from the CTA API
@app.route('/api/get_vehicle/<vehicle_id>')
@login_required
def get_vehicle(vehicle_id):
    if not vehicle_id.isdigit():
        return jsonify({'error': 'Vehicle ID must be numeric'}), 400

    user = current_user
    existing_vehicle = user.tracked_vehicles.filter_by(vehicle_id=vehicle_id).first()
    if existing_vehicle:
        return jsonify({'error': 'This vehicle is already being tracked'}), 409

    try:
        cta_api_key = '' #Please enter API key here
        api_url = f'http://www.ctabustracker.com/bustime/api/v2/getvehicles?key={cta_api_key}&vid={vehicle_id}'
        response = requests.get(api_url)
        data = xmltodict.parse(response.text)

        new_vehicle = TrackedVehicle(vehicle_id=vehicle_id, user=user)
        db.session.add(new_vehicle)
        db.session.commit()

        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})

# Route to get all tracked vehicles
@app.route('/api/get_vehicles')
def get_vehicles():
    try:
        cta_api_key = '' # Please enter API key here
        api_url = f'http://www.ctabustracker.com/bustime/api/v2/getvehicles?key={cta_api_key}'
        response = requests.get(api_url)
        data = xmltodict.parse(response.text)
        if 'bustime-response' in data and 'vehicle' in data['bustime-response']:
            vehicles = data['bustime-response']['vehicle']
            return jsonify({'vehicles': vehicles})
        else:
            return jsonify({'error': 'Invalid vehicle data. Vehicle information not found.'})
    except Exception as e:
        return jsonify({'error': str(e)})

# Route to delete a vehicle from tracking
@app.route('/api/delete_vehicle/<vehicle_id>', methods=['POST'])
@login_required
def delete_vehicle(vehicle_id):
    user = current_user
    vehicle = user.tracked_vehicles.filter_by(vehicle_id=vehicle_id).first()
    if vehicle:
        db.session.delete(vehicle)
        db.session.commit()
        return jsonify({'message': 'Vehicle successfully deleted'}), 200
    else:
        return jsonify({'error': 'Vehicle not found'}), 404

# Route to get details of all tracked vehicles
@app.route('/api/get_tracked_vehicle_details')
@login_required
def get_tracked_vehicle_details():
    user = current_user
    tracked_vehicles = user.tracked_vehicles.all()
    vehicle_details = []
    tracked_vehicle_ids = []

    for vehicle in tracked_vehicles:
        vehicle_id = vehicle.vehicle_id
        tracked_vehicle_ids.append(vehicle_id)
        try:
            cta_api_key = '' #Please enter your API key here
            api_url = f'http://www.ctabustracker.com/bustime/api/v2/getvehicles?key={cta_api_key}&vid={vehicle_id}'
            response = requests.get(api_url)
            data = xmltodict.parse(response.text)
            if 'bustime-response' in data and 'vehicle' in data['bustime-response']:
                vehicle_data = data['bustime-response']['vehicle']
                if isinstance(vehicle_data, dict):
                    vehicle_details.append(vehicle_data)
                else:
                    vehicle_details.extend(vehicle_data)
        except Exception as e:
            print(f"Error fetching vehicle details for {vehicle_id}: {str(e)}")

    return jsonify({'vehicle_details': vehicle_details, 'tracked_vehicle_ids': tracked_vehicle_ids})

# Main function to start the Flask app
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create all database tables
    app.run(debug=True)  # Start the application with debug enabled
